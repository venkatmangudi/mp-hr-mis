require 'test_helper'

class LeaveempTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
