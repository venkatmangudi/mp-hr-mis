require 'test_helper'

class SanctionedPostTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
