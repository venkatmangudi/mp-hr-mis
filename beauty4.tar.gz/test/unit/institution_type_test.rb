require 'test_helper'

class InstitutionTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
