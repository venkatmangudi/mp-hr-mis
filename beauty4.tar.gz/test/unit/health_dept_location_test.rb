require 'test_helper'

class HealthDeptLocationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
