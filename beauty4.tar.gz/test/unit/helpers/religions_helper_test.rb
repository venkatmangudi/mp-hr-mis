require 'test_helper'

class ReligionsHelperTest < ActionView::TestCase
end
