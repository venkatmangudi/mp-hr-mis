require 'test_helper'

class LeaveempsHelperTest < ActionView::TestCase
end
