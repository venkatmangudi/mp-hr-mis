require 'test_helper'

class DistrictsHelperTest < ActionView::TestCase
end
