require 'test_helper'

class MartialStatsHelperTest < ActionView::TestCase
end
