require 'test_helper'

class DependentsHelperTest < ActionView::TestCase
end
