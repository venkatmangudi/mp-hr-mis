require 'test_helper'

class EmpEdusHelperTest < ActionView::TestCase
end
