require 'test_helper'

class SpecialisationsHelperTest < ActionView::TestCase
end
