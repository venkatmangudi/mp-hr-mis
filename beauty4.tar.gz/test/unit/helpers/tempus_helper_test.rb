require 'test_helper'

class TempusHelperTest < ActionView::TestCase
end
