require 'test_helper'

class RelationshipsHelperTest < ActionView::TestCase
end
