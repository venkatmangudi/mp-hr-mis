require 'test_helper'

class EmpSpecViewsHelperTest < ActionView::TestCase
end
