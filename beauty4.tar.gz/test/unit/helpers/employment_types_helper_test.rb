require 'test_helper'

class EmploymentTypesHelperTest < ActionView::TestCase
end
