require 'test_helper'

class SanctionedPostsHelperTest < ActionView::TestCase
end
