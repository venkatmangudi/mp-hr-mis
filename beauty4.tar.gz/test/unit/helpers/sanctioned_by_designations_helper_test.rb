require 'test_helper'

class SanctionedByDesignationsHelperTest < ActionView::TestCase
end
