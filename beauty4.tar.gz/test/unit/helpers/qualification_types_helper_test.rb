require 'test_helper'

class QualificationTypesHelperTest < ActionView::TestCase
end
