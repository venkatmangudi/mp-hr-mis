require 'test_helper'

class EmployeeWorkDetailsHelperTest < ActionView::TestCase
end
