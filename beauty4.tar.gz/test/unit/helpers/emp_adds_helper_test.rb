require 'test_helper'

class EmpAddsHelperTest < ActionView::TestCase
end
