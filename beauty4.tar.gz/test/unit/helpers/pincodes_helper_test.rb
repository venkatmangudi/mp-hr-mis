require 'test_helper'

class PincodesHelperTest < ActionView::TestCase
end
