require 'test_helper'

class AdditionalChargesHelperTest < ActionView::TestCase
end
