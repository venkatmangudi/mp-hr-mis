require 'test_helper'

class RecruitmentModesHelperTest < ActionView::TestCase
end
