require 'test_helper'

class HospitalReportsHelperTest < ActionView::TestCase
end
