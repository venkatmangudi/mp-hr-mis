require 'test_helper'

class InstitutionTypesHelperTest < ActionView::TestCase
end
