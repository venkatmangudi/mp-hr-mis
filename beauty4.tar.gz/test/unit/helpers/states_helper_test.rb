require 'test_helper'

class StatesHelperTest < ActionView::TestCase
end
