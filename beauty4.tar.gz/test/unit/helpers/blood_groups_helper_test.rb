require 'test_helper'

class BloodGroupsHelperTest < ActionView::TestCase
end
