require 'test_helper'

class QualificationsHelperTest < ActionView::TestCase
end
