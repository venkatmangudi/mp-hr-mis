require 'test_helper'

class PostingsHelperTest < ActionView::TestCase
end
