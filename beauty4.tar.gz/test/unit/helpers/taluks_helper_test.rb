require 'test_helper'

class TaluksHelperTest < ActionView::TestCase
end
