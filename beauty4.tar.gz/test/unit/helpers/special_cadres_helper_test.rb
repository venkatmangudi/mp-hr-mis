require 'test_helper'

class SpecialCadresHelperTest < ActionView::TestCase
end
