require 'test_helper'

class BlocksHelperTest < ActionView::TestCase
end
