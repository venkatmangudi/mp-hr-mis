require 'test_helper'

class RelationsHelperTest < ActionView::TestCase
end
