require 'test_helper'

class GendersHelperTest < ActionView::TestCase
end
