require 'test_helper'

class EmployeeAgeByBandsHelperTest < ActionView::TestCase
end
