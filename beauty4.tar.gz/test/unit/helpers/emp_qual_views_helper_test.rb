require 'test_helper'

class EmpQualViewsHelperTest < ActionView::TestCase
end
