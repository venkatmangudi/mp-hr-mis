require 'test_helper'

class EmpGenViewsHelperTest < ActionView::TestCase
end
