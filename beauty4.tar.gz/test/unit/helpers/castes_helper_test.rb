require 'test_helper'

class CastesHelperTest < ActionView::TestCase
end
