require 'test_helper'

class LeaveTypesHelperTest < ActionView::TestCase
end
