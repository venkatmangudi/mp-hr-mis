require 'test_helper'

class EmpTenureByBandsHelperTest < ActionView::TestCase
end
