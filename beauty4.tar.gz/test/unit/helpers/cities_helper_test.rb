require 'test_helper'

class CitiesHelperTest < ActionView::TestCase
end
