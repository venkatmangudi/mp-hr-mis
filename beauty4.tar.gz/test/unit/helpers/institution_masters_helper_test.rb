require 'test_helper'

class InstitutionMastersHelperTest < ActionView::TestCase
end
