require 'test_helper'

class ShowcausesHelperTest < ActionView::TestCase
end
