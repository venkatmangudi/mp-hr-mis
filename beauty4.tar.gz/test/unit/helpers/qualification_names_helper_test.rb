require 'test_helper'

class QualificationNamesHelperTest < ActionView::TestCase
end
