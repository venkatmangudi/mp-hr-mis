require 'test_helper'

class AchievementsHelperTest < ActionView::TestCase
end
