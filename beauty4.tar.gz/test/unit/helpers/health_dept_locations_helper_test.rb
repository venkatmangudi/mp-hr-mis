require 'test_helper'

class HealthDeptLocationsHelperTest < ActionView::TestCase
end
