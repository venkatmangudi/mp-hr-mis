require 'test_helper'

class HospitalTypesHelperTest < ActionView::TestCase
end
