require 'test_helper'

class HospitalReportTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
