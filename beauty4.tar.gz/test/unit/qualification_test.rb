require 'test_helper'

class QualificationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
