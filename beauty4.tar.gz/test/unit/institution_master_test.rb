require 'test_helper'

class InstitutionMasterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
