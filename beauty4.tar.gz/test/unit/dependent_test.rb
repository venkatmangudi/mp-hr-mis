require 'test_helper'

class DependentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
