require 'test_helper'

class EmploymentTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
