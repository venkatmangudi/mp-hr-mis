require 'test_helper'

class EmpGenViewTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
