require 'test_helper'

class TalukTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
