require 'test_helper'

class EmployeeAgeByBandTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
