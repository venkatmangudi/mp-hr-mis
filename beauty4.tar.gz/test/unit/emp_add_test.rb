require 'test_helper'

class EmpAddTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
