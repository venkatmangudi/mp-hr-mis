require 'test_helper'

class EmployeeWorkDetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
