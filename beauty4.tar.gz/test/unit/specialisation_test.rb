require 'test_helper'

class SpecialisationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
