require 'test_helper'

class RecruitmentModeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
