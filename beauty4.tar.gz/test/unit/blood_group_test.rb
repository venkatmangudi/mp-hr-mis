require 'test_helper'

class BloodGroupTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
