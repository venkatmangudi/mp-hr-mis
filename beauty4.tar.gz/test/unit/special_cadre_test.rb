require 'test_helper'

class SpecialCadreTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
