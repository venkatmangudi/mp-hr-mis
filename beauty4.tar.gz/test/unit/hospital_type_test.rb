require 'test_helper'

class HospitalTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
