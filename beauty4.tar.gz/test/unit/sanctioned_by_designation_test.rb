require 'test_helper'

class SanctionedByDesignationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
