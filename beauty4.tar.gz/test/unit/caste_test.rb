require 'test_helper'

class CasteTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
