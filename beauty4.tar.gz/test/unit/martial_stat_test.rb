require 'test_helper'

class MartialStatTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
