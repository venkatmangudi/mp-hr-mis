require 'test_helper'

class ReligionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
