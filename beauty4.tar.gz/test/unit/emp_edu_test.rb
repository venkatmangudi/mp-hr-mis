require 'test_helper'

class EmpEduTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
