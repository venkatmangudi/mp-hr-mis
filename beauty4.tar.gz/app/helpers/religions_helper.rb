module ReligionsHelper
end
