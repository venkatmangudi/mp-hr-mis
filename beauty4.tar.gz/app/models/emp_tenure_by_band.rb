class EmpTenureByBand < ActiveRecord::Base
  self.table_name = 'emp_tenure_by_band' 
end
