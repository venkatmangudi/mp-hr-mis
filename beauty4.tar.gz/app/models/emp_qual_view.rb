class EmpQualView < ActiveRecord::Base
  self.table_name = 'emp_qual_view'
end
