class Report < ActiveRecord::Base
  # attr_accessible :title, :body
  belongs_to:emp_spec_view
end
