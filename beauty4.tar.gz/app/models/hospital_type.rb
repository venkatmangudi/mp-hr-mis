class HospitalType < ActiveRecord::Base
  attr_accessible :hospital_type, :remarks
end
