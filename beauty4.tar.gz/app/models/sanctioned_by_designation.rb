class SanctionedByDesignation < ActiveRecord::Base
	self.table_name = 'sanctioned_by_designation'
end
