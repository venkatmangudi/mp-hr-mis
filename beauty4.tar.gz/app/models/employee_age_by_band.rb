class EmployeeAgeByBand < ActiveRecord::Base
  self.table_name = 'employee_age_by_band'
end
