class Hospital < ActiveRecord::Base
  attr_accessible  :beds, :fax_no, :hospital_name, :phone_no, :district_id, :institution_type_id, :location_id, :division_id, :block_id, :hospital_type_id, :IsAdministrativeLocation, :IsTribal

  belongs_to :district
  belongs_to :division
  belongs_to :institution_type  
  belongs_to :hospital_type
  belongs_to :block

  has_many :hospital_reports
  has_many:health_dept_locations
  has_many:sanctioned_posts
  has_many:postings
end
