class EmpAdd < ActiveRecord::Base
  attr_accessible :emp_alt_email, :emp_alt_mobile, :emp_alt_phone, :emp_dlnum, :emp_id, :emp_identification, :emp_martial_status_id, :emp_pannum, :emp_passportnum, :emp_present_addr, :emp_present_loc_master_id
end
