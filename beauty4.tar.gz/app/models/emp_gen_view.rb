class EmpGenView < ActiveRecord::Base
    self.table_name = 'emp_gen_view' 
end
