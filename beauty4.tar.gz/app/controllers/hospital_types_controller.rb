class HospitalTypesController < InheritedResources::Base
end
