class EmployeeAgeByBandsController < InheritedResources::Base
end
