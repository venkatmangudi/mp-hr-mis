class DesignationsController < InheritedResources::Base
end
