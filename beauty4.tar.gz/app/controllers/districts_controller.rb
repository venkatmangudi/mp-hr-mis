class DistrictsController < InheritedResources::Base
end
