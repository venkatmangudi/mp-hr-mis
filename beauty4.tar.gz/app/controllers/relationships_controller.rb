class RelationshipsController < InheritedResources::Base
end
