class SpecialisationsController < InheritedResources::Base
end
