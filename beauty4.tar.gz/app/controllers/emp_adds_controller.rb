class EmpAddsController < InheritedResources::Base
end
