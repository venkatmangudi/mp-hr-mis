class StatesController < InheritedResources::Base
end
