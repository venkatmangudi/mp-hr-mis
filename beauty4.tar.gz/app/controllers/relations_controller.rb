class RelationsController < InheritedResources::Base
end
