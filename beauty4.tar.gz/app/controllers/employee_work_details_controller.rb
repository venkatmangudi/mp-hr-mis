class EmployeeWorkDetailsController < InheritedResources::Base
end
