class EmpGenViewsController < InheritedResources::Base
end
