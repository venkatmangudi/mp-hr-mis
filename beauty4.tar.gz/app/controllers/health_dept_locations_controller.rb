class HealthDeptLocationsController < InheritedResources::Base
end
