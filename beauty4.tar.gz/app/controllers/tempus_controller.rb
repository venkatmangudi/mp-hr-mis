class TempusController < InheritedResources::Base
end
