class TaluksController < InheritedResources::Base
end
