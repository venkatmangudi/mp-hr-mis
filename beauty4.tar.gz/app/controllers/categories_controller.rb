class CategoriesController < InheritedResources::Base
end
