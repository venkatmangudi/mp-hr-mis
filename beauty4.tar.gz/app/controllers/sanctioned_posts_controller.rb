class SanctionedPostsController < InheritedResources::Base
end
