class EmpQualViewsController < InheritedResources::Base
end
