class RolesController < InheritedResources::Base
end
