class LeaveTypesController < InheritedResources::Base
end
