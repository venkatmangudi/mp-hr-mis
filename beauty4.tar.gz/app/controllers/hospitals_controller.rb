class HospitalsController < InheritedResources::Base
end
