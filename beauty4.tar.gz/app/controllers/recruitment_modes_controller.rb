class RecruitmentModesController < InheritedResources::Base
end
