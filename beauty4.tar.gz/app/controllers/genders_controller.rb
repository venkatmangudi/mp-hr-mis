class GendersController < InheritedResources::Base
end
