class UniversitiesController < InheritedResources::Base
end
