class BlocksController < InheritedResources::Base
end
