class SpecialCadresController < InheritedResources::Base
end
