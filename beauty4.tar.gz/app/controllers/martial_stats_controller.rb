class MartialStatsController < InheritedResources::Base
end
