class PincodesController < InheritedResources::Base
end
