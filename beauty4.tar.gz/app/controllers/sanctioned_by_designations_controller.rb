class SanctionedByDesignationsController < InheritedResources::Base
end
