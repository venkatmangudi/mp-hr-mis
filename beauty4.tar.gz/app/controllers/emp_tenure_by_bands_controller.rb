class EmpTenureByBandsController < InheritedResources::Base
end
