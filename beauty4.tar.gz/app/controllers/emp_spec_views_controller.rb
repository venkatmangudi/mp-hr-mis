class EmpSpecViewsController < InheritedResources::Base
end
