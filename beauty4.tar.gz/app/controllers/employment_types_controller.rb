class EmploymentTypesController < InheritedResources::Base
end
