class BloodGroupsController < InheritedResources::Base
end
