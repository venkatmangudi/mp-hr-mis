class LocationsController < InheritedResources::Base
end
