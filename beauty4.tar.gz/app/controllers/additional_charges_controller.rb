class AdditionalChargesController < InheritedResources::Base
end
