class ReligionsController < InheritedResources::Base
end
