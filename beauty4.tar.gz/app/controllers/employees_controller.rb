class EmployeesController < InheritedResources::Base
end
