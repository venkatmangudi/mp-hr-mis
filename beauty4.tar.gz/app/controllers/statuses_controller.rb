class StatusesController < InheritedResources::Base
end
