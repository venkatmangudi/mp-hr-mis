class CastesController < InheritedResources::Base
end
