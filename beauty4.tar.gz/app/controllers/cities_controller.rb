class CitiesController < InheritedResources::Base
end
