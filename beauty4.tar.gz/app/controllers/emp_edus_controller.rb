class EmpEdusController < InheritedResources::Base
end
