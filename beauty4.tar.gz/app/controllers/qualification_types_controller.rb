class QualificationTypesController < InheritedResources::Base
end
