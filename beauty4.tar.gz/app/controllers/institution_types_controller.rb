class InstitutionTypesController < InheritedResources::Base
end
