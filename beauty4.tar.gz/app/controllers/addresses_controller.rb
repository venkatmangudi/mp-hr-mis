class AddressesController < InheritedResources::Base
end
