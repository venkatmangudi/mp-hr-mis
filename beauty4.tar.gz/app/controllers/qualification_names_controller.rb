class QualificationNamesController < InheritedResources::Base
end
