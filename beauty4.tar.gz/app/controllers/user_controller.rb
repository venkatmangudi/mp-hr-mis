class UserController < InheritedResources::Base
end
