class ReportsController < InheritedResources::Base
end
