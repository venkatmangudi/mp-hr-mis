class HospitalReportsController < InheritedResources::Base
end
