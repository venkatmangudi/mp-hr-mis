class DivisionsController < InheritedResources::Base
end
